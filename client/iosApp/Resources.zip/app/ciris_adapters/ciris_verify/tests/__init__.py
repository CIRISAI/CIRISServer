"""Tests for CIRISVerify adapter."""
